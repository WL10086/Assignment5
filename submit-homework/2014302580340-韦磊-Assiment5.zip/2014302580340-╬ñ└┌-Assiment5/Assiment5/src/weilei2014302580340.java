import java.io.IOException;
import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.mail.Store;

public class weilei2014302580340 implements IMailService {
	String name = "weil340@sina.com";
	String password = "weilei10086";
	Session s;

	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		
		Properties pro = new Properties();
		
		pro.put("mail.smtp.host", "smtp.sina.com");
		
		pro.put("mail.smtp.auth", "true");
		
		pro.setProperty("mail.transport.protocol", "smtp");
		
		s = Session.getInstance(pro); // ���������½�һ���ʼ��Ự
		
		 s.setDebug(true);
	}

	@Override
	public void send(String recipient, String subject, Object content)
			throws MessagingException {
		// TODO Auto-generated method stub
		

		InternetAddress fromAddr = null;
		
		  InternetAddress toAddr = null;
		  
		Message message = new MimeMessage(s);
		
		InternetAddress internetaddress = new InternetAddress(name);
		message.setFrom(internetaddress);
		
		InternetAddress internetAddress = new InternetAddress(recipient);
		message.setRecipient(RecipientType.TO, internetAddress);
		
		message.setSubject(subject);
		
		message.setText(content.toString());
		
		Transport.send(message);

	}

	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		Store store;
		
		Folder box;
		
		connect();
		
		store = s.getStore();
		
		store.connect();
		// ����ʼ���
		box =store.getFolder("inbox");
		box.open(Folder.READ_ONLY);
		// �鿴�Ƿ������ʼ�
		if (box.getNewMessageCount() == 0)
			return false;
		else {
			return true;
		}

	}

	@Override
	public String getReplyMessageContent(String sender, String subject)
			throws MessagingException, IOException {
		// TODO Auto-generated method stub
		Folder box;
		Store store;
		connect();
		store = s.getStore();
		store.connect();
		// ����ʼ���
		box = store.getFolder("inbox");
		box.open(Folder.READ_ONLY);
		Message message = box.getMessage(box.getMessageCount());
		return message.getSubject().toString()
				+ message.getContent().toString();
	}
}
